<?php echo $heading; ?>
<?php echo $message; ?>