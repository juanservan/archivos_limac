<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-06 18:45:23 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-07-06 18:53:09 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\controllers\Website.php 188
ERROR - 2017-07-06 19:01:26 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\application\models\Datamorph_model.php 127
ERROR - 2017-07-06 19:01:26 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\application\models\Datamorph_model.php 127
ERROR - 2017-07-06 19:01:46 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\application\models\Datamorph_model.php 128
ERROR - 2017-07-06 19:01:46 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\application\models\Datamorph_model.php 128
ERROR - 2017-07-06 19:02:07 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\application\models\Datamorph_model.php 128
ERROR - 2017-07-06 19:02:07 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\application\models\Datamorph_model.php 128
ERROR - 2017-07-06 19:10:46 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\system\helpers\form_helper.php 400
ERROR - 2017-07-06 19:10:46 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\system\helpers\form_helper.php 400
ERROR - 2017-07-06 19:16:13 --> Severity: Error --> Call to undefined method Website::show_table_form() C:\UwAmp\www\frisk\application\controllers\Website.php 214
ERROR - 2017-07-06 19:30:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\controllers\Website.php 187
ERROR - 2017-07-06 19:30:15 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\UwAmp\www\frisk\application\views\create\create_new_table_view.php 74
ERROR - 2017-07-06 19:30:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\controllers\Website.php 187
ERROR - 2017-07-06 19:30:23 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\UwAmp\www\frisk\application\views\create\create_new_table_view.php 74
ERROR - 2017-07-06 19:30:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\controllers\Website.php 187
ERROR - 2017-07-06 19:30:32 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\UwAmp\www\frisk\application\views\create\create_new_table_view.php 74
ERROR - 2017-07-06 19:30:37 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\UwAmp\www\frisk\application\views\create\create_new_table_view.php 74
ERROR - 2017-07-06 19:30:41 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\UwAmp\www\frisk\application\views\create\create_new_table_view.php 74
ERROR - 2017-07-06 19:31:17 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\UwAmp\www\frisk\application\views\create\create_new_table_view.php 74
ERROR - 2017-07-06 19:31:31 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\UwAmp\www\frisk\application\views\create\create_new_table_view.php 83
ERROR - 2017-07-06 19:31:43 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\UwAmp\www\frisk\application\views\create\create_new_table_view.php 93
ERROR - 2017-07-06 19:32:10 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\UwAmp\www\frisk\application\views\create\create_new_table_view.php 139
ERROR - 2017-07-06 19:32:35 --> Severity: Warning --> Illegal string offset 'field_name' C:\UwAmp\www\frisk\system\libraries\Form_validation.php 546
ERROR - 2017-07-06 19:32:35 --> Severity: Error --> Cannot create references to/from string offsets nor overloaded objects C:\UwAmp\www\frisk\system\libraries\Form_validation.php 546
ERROR - 2017-07-06 19:33:08 --> Severity: Warning --> Illegal string offset 'field_name' C:\UwAmp\www\frisk\system\libraries\Form_validation.php 546
ERROR - 2017-07-06 19:33:08 --> Severity: Error --> Cannot create references to/from string offsets nor overloaded objects C:\UwAmp\www\frisk\system\libraries\Form_validation.php 546
ERROR - 2017-07-06 19:34:11 --> Could not find the language line "form_validation_email"
ERROR - 2017-07-06 19:36:14 --> Severity: Warning --> Illegal string offset 'field_name' C:\UwAmp\www\frisk\system\libraries\Form_validation.php 546
ERROR - 2017-07-06 19:36:14 --> Severity: Error --> Cannot create references to/from string offsets nor overloaded objects C:\UwAmp\www\frisk\system\libraries\Form_validation.php 546
ERROR - 2017-07-06 19:36:21 --> Severity: Warning --> Illegal string offset 'field_name' C:\UwAmp\www\frisk\system\libraries\Form_validation.php 546
ERROR - 2017-07-06 19:36:21 --> Severity: Error --> Cannot create references to/from string offsets nor overloaded objects C:\UwAmp\www\frisk\system\libraries\Form_validation.php 546
ERROR - 2017-07-06 19:36:37 --> Severity: Warning --> Illegal string offset 'field_name' C:\UwAmp\www\frisk\system\libraries\Form_validation.php 546
ERROR - 2017-07-06 19:36:37 --> Severity: Error --> Cannot create references to/from string offsets nor overloaded objects C:\UwAmp\www\frisk\system\libraries\Form_validation.php 546
ERROR - 2017-07-06 19:36:40 --> Severity: Warning --> Illegal string offset 'field_name' C:\UwAmp\www\frisk\system\libraries\Form_validation.php 546
ERROR - 2017-07-06 19:36:40 --> Severity: Error --> Cannot create references to/from string offsets nor overloaded objects C:\UwAmp\www\frisk\system\libraries\Form_validation.php 546
ERROR - 2017-07-06 19:38:40 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\system\helpers\form_helper.php 949
ERROR - 2017-07-06 19:45:09 --> Severity: Parsing Error --> syntax error, unexpected 'endfor' (T_ENDFOR) C:\UwAmp\www\frisk\application\views\create\create_new_table_view.php 183
ERROR - 2017-07-06 19:45:24 --> Severity: Parsing Error --> syntax error, unexpected '?>', expecting '(' C:\UwAmp\www\frisk\application\views\create\create_new_table_view.php 183
ERROR - 2017-07-06 19:45:29 --> Severity: Parsing Error --> syntax error, unexpected 'endfor' (T_ENDFOR) C:\UwAmp\www\frisk\application\views\create\create_new_table_view.php 183
ERROR - 2017-07-06 19:51:05 --> Severity: Notice --> Undefined variable: row_ids C:\UwAmp\www\frisk\application\controllers\Website.php 226
ERROR - 2017-07-06 19:52:21 --> Severity: Notice --> Undefined variable: i C:\UwAmp\www\frisk\application\controllers\Website.php 190
ERROR - 2017-07-06 19:52:40 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 191
ERROR - 2017-07-06 19:52:40 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 192
ERROR - 2017-07-06 19:52:40 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 193
ERROR - 2017-07-06 19:52:40 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 196
ERROR - 2017-07-06 19:52:40 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 197
ERROR - 2017-07-06 19:52:40 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 198
ERROR - 2017-07-06 19:52:40 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 199
ERROR - 2017-07-06 19:52:40 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 200
ERROR - 2017-07-06 19:52:40 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 201
ERROR - 2017-07-06 19:52:40 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 202
ERROR - 2017-07-06 19:52:40 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 203
ERROR - 2017-07-06 19:52:40 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 204
ERROR - 2017-07-06 19:52:40 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 205
ERROR - 2017-07-06 19:52:40 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 191
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 192
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 193
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 196
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 197
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 198
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 199
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 200
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 201
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 202
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 203
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 204
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 205
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 191
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 192
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 193
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 196
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 197
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 198
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 199
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 200
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 201
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 202
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 203
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 204
ERROR - 2017-07-06 19:52:41 --> Severity: Notice --> Undefined variable: id C:\UwAmp\www\frisk\application\controllers\Website.php 205
ERROR - 2017-07-06 19:53:03 --> Severity: Notice --> Undefined variable: row_id C:\UwAmp\www\frisk\application\controllers\Website.php 192
ERROR - 2017-07-06 19:53:03 --> Severity: Notice --> Undefined variable: row_id C:\UwAmp\www\frisk\application\controllers\Website.php 193
ERROR - 2017-07-06 19:53:03 --> Severity: Notice --> Undefined variable: row_id C:\UwAmp\www\frisk\application\controllers\Website.php 192
ERROR - 2017-07-06 19:53:03 --> Severity: Notice --> Undefined variable: row_id C:\UwAmp\www\frisk\application\controllers\Website.php 193
ERROR - 2017-07-06 19:53:03 --> Severity: Notice --> Undefined variable: row_id C:\UwAmp\www\frisk\application\controllers\Website.php 192
ERROR - 2017-07-06 19:53:03 --> Severity: Notice --> Undefined variable: row_id C:\UwAmp\www\frisk\application\controllers\Website.php 193
ERROR - 2017-07-06 20:12:30 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\UwAmp\www\frisk\application\views\create\create_new_table_view.php 169
ERROR - 2017-07-06 20:16:38 --> Severity: Error --> Call to undefined method Datamorph::types() C:\UwAmp\www\frisk\application\views\create\create_new_table_view.php 85
ERROR - 2017-07-06 20:40:16 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\controllers\Website.php 214
ERROR - 2017-07-06 20:40:16 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 85
ERROR - 2017-07-06 20:40:16 --> Severity: Notice --> Undefined index: index C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 86
ERROR - 2017-07-06 20:40:16 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 85
ERROR - 2017-07-06 20:40:16 --> Severity: Notice --> Undefined index: index C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 86
ERROR - 2017-07-06 20:40:16 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 85
ERROR - 2017-07-06 20:40:16 --> Severity: Notice --> Undefined index: index C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 86
ERROR - 2017-07-06 20:40:16 --> Severity: Notice --> Undefined index: rows C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 96
ERROR - 2017-07-06 20:43:27 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\controllers\Website.php 214
ERROR - 2017-07-06 20:43:27 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 85
ERROR - 2017-07-06 20:43:27 --> Severity: Notice --> Undefined index: index C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 86
ERROR - 2017-07-06 20:43:27 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 85
ERROR - 2017-07-06 20:43:27 --> Severity: Notice --> Undefined index: index C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 86
ERROR - 2017-07-06 20:43:27 --> Severity: Notice --> Undefined index: rows C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 96
ERROR - 2017-07-06 20:43:51 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 86
ERROR - 2017-07-06 20:43:51 --> Severity: Notice --> Undefined index: index C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 87
ERROR - 2017-07-06 20:43:51 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 86
ERROR - 2017-07-06 20:43:51 --> Severity: Notice --> Undefined index: index C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 87
ERROR - 2017-07-06 20:43:51 --> Severity: Notice --> Undefined index: rows C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 97
ERROR - 2017-07-06 20:44:16 --> Severity: Notice --> Undefined index: index C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 87
ERROR - 2017-07-06 20:44:16 --> Severity: Notice --> Undefined index: index C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 87
ERROR - 2017-07-06 20:44:16 --> Severity: Notice --> Undefined index: rows C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 97
ERROR - 2017-07-06 20:44:32 --> Severity: Notice --> Undefined index: rows C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 97
ERROR - 2017-07-06 20:46:00 --> Severity: Notice --> Undefined index: rows C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 96
ERROR - 2017-07-06 20:47:17 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\controllers\Website.php 214
ERROR - 2017-07-06 20:47:29 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\application\models\Datamorph_model.php 129
ERROR - 2017-07-06 20:47:29 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\application\models\Datamorph_model.php 129
ERROR - 2017-07-06 20:47:29 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\system\helpers\form_helper.php 400
ERROR - 2017-07-06 20:48:10 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\application\models\Datamorph_model.php 130
ERROR - 2017-07-06 20:48:10 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\application\models\Datamorph_model.php 130
ERROR - 2017-07-06 20:48:10 --> Severity: Notice --> Array to string conversion C:\UwAmp\www\frisk\system\helpers\form_helper.php 400
ERROR - 2017-07-06 20:49:45 --> 404 Page Not Found: Create/delete_table
ERROR - 2017-07-06 20:50:26 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\controllers\Website.php 214
ERROR - 2017-07-06 20:51:30 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\controllers\Website.php 214
ERROR - 2017-07-06 20:52:20 --> Severity: Notice --> Undefined index: foreign_key C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 91
ERROR - 2017-07-06 20:52:40 --> Severity: Notice --> Undefined index: foreign_key C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 92
ERROR - 2017-07-06 20:52:51 --> Severity: Notice --> Undefined index: foreign_key C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 92
ERROR - 2017-07-06 21:00:07 --> 404 Page Not Found: Search/index
ERROR - 2017-07-06 21:03:39 --> Severity: Parsing Error --> syntax error, unexpected '.' C:\UwAmp\www\frisk\application\models\Datamorph_model.php 388
ERROR - 2017-07-06 21:07:25 --> Severity: Notice --> Undefined property: Website::$database_model C:\UwAmp\www\frisk\application\controllers\Website.php 127
ERROR - 2017-07-06 21:07:25 --> Severity: Error --> Call to a member function rename_session_database() on null C:\UwAmp\www\frisk\application\controllers\Website.php 127
ERROR - 2017-07-06 21:07:31 --> Severity: Notice --> Undefined property: Website::$database_model C:\UwAmp\www\frisk\application\controllers\Website.php 126
ERROR - 2017-07-06 21:07:31 --> Severity: Error --> Call to a member function rename_session_database() on null C:\UwAmp\www\frisk\application\controllers\Website.php 126
ERROR - 2017-07-06 21:27:19 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\controllers\Website.php 207
ERROR - 2017-07-06 21:27:23 --> 404 Page Not Found: Create/delete_table
ERROR - 2017-07-06 21:31:30 --> 404 Page Not Found: Create/delete_table
ERROR - 2017-07-06 21:31:47 --> 404 Page Not Found: Create/delete_table
ERROR - 2017-07-06 21:41:28 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\controllers\Website.php 207
ERROR - 2017-07-06 21:41:56 --> 404 Page Not Found: Create/edit
ERROR - 2017-07-06 21:44:24 --> 404 Page Not Found: Create/edit
ERROR - 2017-07-06 21:44:40 --> Severity: Error --> Call to undefined method Datamorph_model::get_session_table() C:\UwAmp\www\frisk\application\controllers\Website.php 250
ERROR - 2017-07-06 22:07:23 --> Severity: Notice --> Undefined variable: i C:\UwAmp\www\frisk\application\views\create\create_edit_table_view.php 67
ERROR - 2017-07-06 22:07:37 --> Severity: Notice --> Undefined variable: i C:\UwAmp\www\frisk\application\views\create\create_edit_table_view.php 67
ERROR - 2017-07-06 22:11:37 --> Severity: Parsing Error --> syntax error, unexpected 'endfor' (T_ENDFOR) C:\UwAmp\www\frisk\application\views\create\create_edit_table_view.php 203
ERROR - 2017-07-06 22:11:46 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\UwAmp\www\frisk\application\views\create\create_edit_table_view.php 203
ERROR - 2017-07-06 22:14:58 --> Severity: Notice --> Undefined index: foreign_key C:\UwAmp\www\frisk\application\views\create\create_edit_table_view.php 158
ERROR - 2017-07-06 22:15:51 --> Severity: Notice --> Undefined index: foreign_key C:\UwAmp\www\frisk\application\views\create\create_edit_table_view.php 158
ERROR - 2017-07-06 22:15:52 --> Severity: Notice --> Undefined index: foreign_key C:\UwAmp\www\frisk\application\views\create\create_edit_table_view.php 158
ERROR - 2017-07-06 22:19:45 --> Severity: Notice --> Undefined index: on_update C:\UwAmp\www\frisk\application\views\create\create_edit_table_view.php 169
ERROR - 2017-07-06 22:19:45 --> Severity: Notice --> Undefined index: on_update C:\UwAmp\www\frisk\application\views\create\create_edit_table_view.php 169
ERROR - 2017-07-06 22:20:36 --> Severity: Notice --> Undefined index: on_delete C:\UwAmp\www\frisk\application\views\create\create_edit_table_view.php 169
ERROR - 2017-07-06 22:20:36 --> Severity: Notice --> Undefined index: on_delete C:\UwAmp\www\frisk\application\views\create\create_edit_table_view.php 169
ERROR - 2017-07-06 22:20:37 --> Severity: Notice --> Undefined index: on_delete C:\UwAmp\www\frisk\application\views\create\create_edit_table_view.php 169
ERROR - 2017-07-06 22:20:37 --> Severity: Notice --> Undefined index: on_delete C:\UwAmp\www\frisk\application\views\create\create_edit_table_view.php 169
ERROR - 2017-07-06 22:23:23 --> Severity: Parsing Error --> syntax error, unexpected ':', expecting ',' or ';' C:\UwAmp\www\frisk\application\views\create\create_edit_table_view.php 176
ERROR - 2017-07-06 22:23:50 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\UwAmp\www\frisk\application\views\create\create_edit_table_view.php 176
ERROR - 2017-07-06 22:24:02 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ',' or ';' C:\UwAmp\www\frisk\application\views\create\create_edit_table_view.php 176
ERROR - 2017-07-06 22:25:29 --> Severity: Parsing Error --> syntax error, unexpected ':' C:\UwAmp\www\frisk\application\views\create\create_edit_table_view.php 195
