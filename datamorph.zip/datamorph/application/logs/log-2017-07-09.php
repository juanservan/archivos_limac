<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-09 18:34:15 --> 404 Page Not Found: Database/demo
ERROR - 2017-07-09 18:34:17 --> 404 Page Not Found: Database/demo
ERROR - 2017-07-09 18:35:58 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-07-09 18:38:48 --> Severity: Warning --> Missing argument 1 for Website::database() C:\UwAmp\www\frisk\application\controllers\Website.php 113
ERROR - 2017-07-09 18:38:48 --> Severity: Notice --> Undefined variable: database C:\UwAmp\www\frisk\application\controllers\Website.php 115
ERROR - 2017-07-09 18:38:48 --> Severity: Notice --> Undefined property: Website::$get_model C:\UwAmp\www\frisk\application\controllers\Website.php 116
ERROR - 2017-07-09 18:38:48 --> Severity: Error --> Call to a member function tables() on null C:\UwAmp\www\frisk\application\controllers\Website.php 116
ERROR - 2017-07-09 18:39:09 --> Severity: Warning --> Missing argument 1 for Website::database() C:\UwAmp\www\frisk\application\controllers\Website.php 113
ERROR - 2017-07-09 18:39:09 --> Severity: Notice --> Undefined variable: database C:\UwAmp\www\frisk\application\controllers\Website.php 117
ERROR - 2017-07-09 18:39:09 --> Severity: Notice --> Undefined variable: database C:\UwAmp\www\frisk\application\controllers\Website.php 118
ERROR - 2017-07-09 18:39:35 --> Severity: Warning --> Missing argument 1 for Website::database() C:\UwAmp\www\frisk\application\controllers\Website.php 113
ERROR - 2017-07-09 18:39:35 --> Severity: Notice --> Undefined variable: database C:\UwAmp\www\frisk\application\controllers\Website.php 115
ERROR - 2017-07-09 18:39:35 --> Severity: Notice --> Undefined variable: database C:\UwAmp\www\frisk\application\controllers\Website.php 118
ERROR - 2017-07-09 18:39:35 --> Severity: Notice --> Undefined variable: database C:\UwAmp\www\frisk\application\controllers\Website.php 119
ERROR - 2017-07-09 18:40:56 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\database\view_tables.php 1
ERROR - 2017-07-09 18:49:36 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\database\view_tables.php 47
ERROR - 2017-07-09 18:49:36 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\database\view_tables.php 47
ERROR - 2017-07-09 20:28:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Get_model C:\UwAmp\www\frisk\system\core\Loader.php 344
ERROR - 2017-07-09 20:29:56 --> 404 Page Not Found: Website/table
ERROR - 2017-07-09 20:31:24 --> Severity: Warning --> Missing argument 2 for Website::table() C:\UwAmp\www\frisk\application\controllers\Website.php 128
ERROR - 2017-07-09 20:31:24 --> Severity: Notice --> Undefined variable: table C:\UwAmp\www\frisk\application\controllers\Website.php 130
ERROR - 2017-07-09 20:31:24 --> Severity: Notice --> Undefined property: Website::$get_model C:\UwAmp\www\frisk\application\controllers\Website.php 131
ERROR - 2017-07-09 20:31:24 --> Severity: Error --> Call to a member function table() on null C:\UwAmp\www\frisk\application\controllers\Website.php 131
ERROR - 2017-07-09 20:31:46 --> Severity: Notice --> Undefined property: Website::$get_model C:\UwAmp\www\frisk\application\controllers\Website.php 131
ERROR - 2017-07-09 20:31:46 --> Severity: Error --> Call to a member function table() on null C:\UwAmp\www\frisk\application\controllers\Website.php 131
ERROR - 2017-07-09 20:32:12 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\database\view_table_data.php 1
ERROR - 2017-07-09 20:32:12 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:32:12 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:32:13 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:32:13 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:33:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:33:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:33:40 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:33:40 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:34:02 --> Severity: Notice --> Undefined property: stdClass::$table C:\UwAmp\www\frisk\application\views\database\view_table_data.php 80
ERROR - 2017-07-09 20:34:02 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:34:02 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:34:02 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:34:02 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:34:07 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:34:07 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:34:26 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:34:26 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:34:26 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:35:12 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:35:12 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:35:12 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:35:21 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:35:21 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:35:42 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:35:42 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:37:01 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:37:01 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:37:55 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:37:55 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:37:58 --> 404 Page Not Found: Download/sample
ERROR - 2017-07-09 20:38:25 --> Query error: Table 'sample.sample' doesn't exist - Invalid query: SHOW CREATE TABLE `sample`.`sample`
ERROR - 2017-07-09 20:38:28 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:38:28 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:38:29 --> Query error: Table 'sample.sample' doesn't exist - Invalid query: SHOW CREATE TABLE `sample`.`sample`
ERROR - 2017-07-09 20:38:31 --> Query error: Table 'sample.sample' doesn't exist - Invalid query: SHOW CREATE TABLE `sample`.`sample`
ERROR - 2017-07-09 20:39:13 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:39:13 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:39:25 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:39:25 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:39:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:39:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:39:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:39:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:39:55 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:39:55 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:40:20 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:40:20 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:40:38 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:40:38 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:40:38 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:40:38 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:41:02 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:41:02 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:41:02 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:41:02 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:41:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:41:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:41:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:41:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:42:03 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:42:03 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:42:03 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:42:03 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:42:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:42:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:42:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:43:48 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:43:48 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:43:59 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:43:59 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:44:13 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:44:13 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:44:13 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:44:13 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:44:25 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:44:25 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:44:25 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:44:25 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:45:01 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:45:01 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:45:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:45:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:46:30 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:46:30 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:46:30 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:46:30 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:47:28 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:47:28 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:47:28 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:47:28 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:48:39 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:48:39 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:48:39 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:48:39 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:48:48 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:48:48 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:48:48 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:48:48 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:49:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:49:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:49:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:49:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:50:15 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:50:15 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:50:26 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:50:26 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:50:48 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:50:48 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:51:13 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:51:13 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:51:13 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:51:13 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:51:39 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:51:39 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:51:39 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:51:39 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:52:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:52:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:52:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:52:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:52:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:52:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:52:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:52:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:52:43 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:52:43 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:52:43 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:52:43 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:53:05 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:53:05 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 20:53:05 --> 404 Page Not Found: Assets/js
ERROR - 2017-07-09 21:03:25 --> Severity: Notice --> Undefined property: Website::$datamorph_model C:\UwAmp\www\frisk\application\controllers\Website.php 132
ERROR - 2017-07-09 21:03:25 --> Severity: Error --> Call to a member function table_count_rows() on null C:\UwAmp\www\frisk\application\controllers\Website.php 132
ERROR - 2017-07-09 21:03:42 --> Severity: Notice --> Undefined property: Website::$pagination C:\UwAmp\www\frisk\application\controllers\Website.php 247
ERROR - 2017-07-09 21:03:42 --> Severity: Error --> Call to a member function initialize() on null C:\UwAmp\www\frisk\application\controllers\Website.php 247
ERROR - 2017-07-09 21:07:26 --> Severity: Notice --> Undefined variable: product_options C:\UwAmp\www\frisk\application\controllers\Website.php 221
ERROR - 2017-07-09 21:07:26 --> Severity: Notice --> Undefined variable: product_options C:\UwAmp\www\frisk\application\controllers\Website.php 221
ERROR - 2017-07-09 21:07:45 --> Severity: Notice --> Undefined variable: limit C:\UwAmp\www\frisk\application\controllers\Website.php 221
ERROR - 2017-07-09 21:07:45 --> Severity: Notice --> Undefined variable: limit C:\UwAmp\www\frisk\application\controllers\Website.php 221
