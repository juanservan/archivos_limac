<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-10 06:54:38 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-07-10 06:54:44 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-07-10 06:59:27 --> Severity: Notice --> Undefined variable: server C:\UwAmp\www\frisk\application\views\includes\header.php 87
ERROR - 2017-07-10 06:59:27 --> Severity: Notice --> Undefined variable: server C:\UwAmp\www\frisk\application\views\includes\header.php 87
ERROR - 2017-07-10 07:00:16 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\UwAmp\www\frisk\application\views\includes\header.php 36
