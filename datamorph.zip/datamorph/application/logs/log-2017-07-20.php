<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-20 18:56:01 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-07-20 18:59:05 --> Severity: error --> Exception: Unable to locate the model you have specified: Update_model C:\UwAmp\www\frisk\system\core\Loader.php 344
ERROR - 2017-07-20 19:09:42 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\UwAmp\www\frisk\application\controllers\Website.php 156
ERROR - 2017-07-20 19:18:45 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) C:\UwAmp\www\frisk\application\views\database\view_table_data.php 109
ERROR - 2017-07-20 19:51:54 --> Severity: Notice --> Undefined variable: connection C:\UwAmp\www\frisk\application\models\Datamorph_model.php 861
ERROR - 2017-07-20 19:51:54 --> Severity: Error --> Call to a member function table_exists() on null C:\UwAmp\www\frisk\application\models\Datamorph_model.php 861
ERROR - 2017-07-20 19:52:57 --> Query error: Unknown table 'sample.people' - Invalid query: DROP TABLE `people`
