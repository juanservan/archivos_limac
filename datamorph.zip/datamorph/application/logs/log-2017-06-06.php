<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-06 18:08:12 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2017-06-06 18:08:25 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2017-06-06 18:08:25 --> Severity: Warning --> Creating default object from empty value C:\UwAmp\www\frisk\application\controllers\Browse.php 210
ERROR - 2017-06-06 18:08:25 --> 404 Page Not Found: Browse/index
ERROR - 2017-06-06 18:08:29 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2017-06-06 18:08:32 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2017-06-06 18:08:45 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2017-06-06 18:08:51 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2017-06-06 18:12:26 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2017-06-06 18:12:26 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 54
ERROR - 2017-06-06 18:12:26 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 57
ERROR - 2017-06-06 18:12:26 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 60
ERROR - 2017-06-06 18:12:26 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 63
ERROR - 2017-06-06 18:16:15 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2017-06-06 18:16:15 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 42
ERROR - 2017-06-06 18:16:15 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 45
ERROR - 2017-06-06 18:16:15 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 48
ERROR - 2017-06-06 18:16:15 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 51
ERROR - 2017-06-06 18:16:15 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\UwAmp\www\frisk\application\views\includes\footer.php 79
ERROR - 2017-06-06 18:18:29 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2017-06-06 18:18:29 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 42
ERROR - 2017-06-06 18:18:29 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 45
ERROR - 2017-06-06 18:18:29 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 48
ERROR - 2017-06-06 18:18:29 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 51
ERROR - 2017-06-06 18:18:29 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\UwAmp\www\frisk\application\views\includes\footer.php 79
ERROR - 2017-06-06 18:19:23 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2017-06-06 18:19:23 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 31
ERROR - 2017-06-06 18:19:23 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 34
ERROR - 2017-06-06 18:19:23 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 37
ERROR - 2017-06-06 18:19:23 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 40
ERROR - 2017-06-06 18:19:23 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\UwAmp\www\frisk\application\views\includes\footer.php 79
ERROR - 2017-06-06 18:19:37 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2017-06-06 18:19:37 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 31
ERROR - 2017-06-06 18:19:37 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 34
ERROR - 2017-06-06 18:19:37 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 37
ERROR - 2017-06-06 18:19:37 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 40
ERROR - 2017-06-06 18:19:37 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\UwAmp\www\frisk\application\views\includes\footer.php 79
ERROR - 2017-06-06 19:19:45 --> Severity: error --> Exception: Unable to locate the model you have specified: Frisk C:\UwAmp\www\frisk\system\core\Loader.php 344
ERROR - 2017-06-06 19:20:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Frisk C:\UwAmp\www\frisk\system\core\Loader.php 344
ERROR - 2017-06-06 19:21:03 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2017-06-06 19:21:03 --> Severity: Notice --> Undefined property: CI_Loader::$datamorph C:\UwAmp\www\frisk\application\views\includes\header.php 11
ERROR - 2017-06-06 19:21:03 --> Severity: Error --> Call to a member function databases() on null C:\UwAmp\www\frisk\application\views\includes\header.php 11
ERROR - 2017-06-06 19:22:13 --> Severity: Notice --> Undefined property: CI_Loader::$datamorph C:\UwAmp\www\frisk\application\views\includes\header.php 11
ERROR - 2017-06-06 19:22:13 --> Severity: Error --> Call to a member function databases() on null C:\UwAmp\www\frisk\application\views\includes\header.php 11
ERROR - 2017-06-06 19:22:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\UwAmp\www\frisk\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-06-06 19:22:48 --> Unable to connect to the database
ERROR - 2017-06-06 19:27:42 --> 404 Page Not Found: Login/index
ERROR - 2017-06-06 19:28:48 --> 404 Page Not Found: Login/index
ERROR - 2017-06-06 19:28:52 --> 404 Page Not Found: Login/index
ERROR - 2017-06-06 19:30:03 --> 404 Page Not Found: Login/index
ERROR - 2017-06-06 19:34:53 --> 404 Page Not Found: Login/index
ERROR - 2017-06-06 19:35:45 --> 404 Page Not Found: Login/index
ERROR - 2017-06-06 19:36:00 --> 404 Page Not Found: Login/index
ERROR - 2017-06-06 19:36:48 --> Severity: Warning --> Missing argument 1 for CI_URI::segment(), called in C:\UwAmp\www\frisk\application\controllers\Home.php on line 10 and defined C:\UwAmp\www\frisk\system\core\URI.php 344
ERROR - 2017-06-06 19:36:48 --> Severity: Notice --> Undefined variable: n C:\UwAmp\www\frisk\system\core\URI.php 346
ERROR - 2017-06-06 19:42:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\UwAmp\www\frisk\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-06-06 19:42:35 --> Unable to connect to the database
ERROR - 2017-06-06 19:43:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\UwAmp\www\frisk\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-06-06 19:43:52 --> Unable to connect to the database
ERROR - 2017-06-06 19:54:22 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-06-06 19:54:23 --> 404 Page Not Found: Assets/css
ERROR - 2017-06-06 19:54:23 --> 404 Page Not Found: Assets/css
ERROR - 2017-06-06 19:56:10 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-06-06 19:56:12 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-06-06 19:56:40 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-06-06 19:57:13 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-06-06 19:58:03 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-06-06 19:58:57 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-06-06 20:02:08 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-06-06 20:02:37 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-06-06 20:03:01 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-06-06 20:03:11 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-06-06 20:03:32 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-06-06 20:03:35 --> Severity: Notice --> Undefined property: Website::$login_model C:\UwAmp\www\frisk\application\controllers\Website.php 52
ERROR - 2017-06-06 20:03:35 --> Severity: Error --> Call to a member function authenticate() on null C:\UwAmp\www\frisk\application\controllers\Website.php 52
ERROR - 2017-06-06 20:10:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\UwAmp\www\frisk\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-06-06 20:10:32 --> Unable to connect to the database
ERROR - 2017-06-06 20:11:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\UwAmp\www\frisk\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-06-06 20:11:55 --> Unable to connect to the database
ERROR - 2017-06-06 20:12:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\UwAmp\www\frisk\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-06-06 20:12:16 --> Unable to connect to the database
ERROR - 2017-06-06 20:12:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\UwAmp\www\frisk\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-06-06 20:12:44 --> Unable to connect to the database
ERROR - 2017-06-06 20:15:00 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\home_view.php 1
ERROR - 2017-06-06 20:15:00 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 32
ERROR - 2017-06-06 20:15:00 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 35
ERROR - 2017-06-06 20:15:00 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 38
ERROR - 2017-06-06 20:15:00 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 41
ERROR - 2017-06-06 20:15:00 --> Severity: Notice --> Undefined variable: databases C:\UwAmp\www\frisk\application\views\home_view.php 36
ERROR - 2017-06-06 20:15:00 --> Severity: Notice --> Undefined variable: databases C:\UwAmp\www\frisk\application\views\home_view.php 60
ERROR - 2017-06-06 20:15:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\home_view.php 60
ERROR - 2017-06-06 20:15:00 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\UwAmp\www\frisk\application\views\includes\footer.php 79
ERROR - 2017-06-06 20:15:27 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 32
ERROR - 2017-06-06 20:15:27 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 35
ERROR - 2017-06-06 20:15:27 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 38
ERROR - 2017-06-06 20:15:27 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 41
ERROR - 2017-06-06 20:15:27 --> Severity: Notice --> Undefined variable: databases C:\UwAmp\www\frisk\application\views\home_view.php 36
ERROR - 2017-06-06 20:15:27 --> Severity: Notice --> Undefined variable: databases C:\UwAmp\www\frisk\application\views\home_view.php 60
ERROR - 2017-06-06 20:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\home_view.php 60
ERROR - 2017-06-06 20:15:27 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\UwAmp\www\frisk\application\views\includes\footer.php 79
ERROR - 2017-06-06 20:16:06 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 31
ERROR - 2017-06-06 20:16:06 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 34
ERROR - 2017-06-06 20:16:06 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 37
ERROR - 2017-06-06 20:16:06 --> Severity: Notice --> Undefined variable: navlink C:\UwAmp\www\frisk\application\views\includes\header.php 40
ERROR - 2017-06-06 20:16:06 --> Severity: Notice --> Undefined variable: databases C:\UwAmp\www\frisk\application\views\home_view.php 36
ERROR - 2017-06-06 20:16:06 --> Severity: Notice --> Undefined variable: databases C:\UwAmp\www\frisk\application\views\home_view.php 60
ERROR - 2017-06-06 20:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\home_view.php 60
ERROR - 2017-06-06 20:16:06 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\UwAmp\www\frisk\application\views\includes\footer.php 79
ERROR - 2017-06-06 20:21:45 --> Severity: Notice --> Undefined variable: link C:\UwAmp\www\frisk\application\views\includes\header.php 27
ERROR - 2017-06-06 20:21:45 --> Severity: Notice --> Undefined variable: link C:\UwAmp\www\frisk\application\views\includes\header.php 33
ERROR - 2017-06-06 20:21:45 --> Severity: Notice --> Undefined variable: link C:\UwAmp\www\frisk\application\views\includes\header.php 33
ERROR - 2017-06-06 20:21:45 --> Severity: Notice --> Undefined variable: link C:\UwAmp\www\frisk\application\views\includes\header.php 33
ERROR - 2017-06-06 20:21:45 --> Severity: Notice --> Undefined variable: link C:\UwAmp\www\frisk\application\views\includes\header.php 33
ERROR - 2017-06-06 20:21:45 --> Severity: Notice --> Undefined variable: databases C:\UwAmp\www\frisk\application\views\home_view.php 36
ERROR - 2017-06-06 20:21:45 --> Severity: Notice --> Undefined variable: databases C:\UwAmp\www\frisk\application\views\home_view.php 60
ERROR - 2017-06-06 20:21:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\home_view.php 60
ERROR - 2017-06-06 20:21:45 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\UwAmp\www\frisk\application\views\includes\footer.php 79
ERROR - 2017-06-06 20:23:31 --> Severity: Notice --> Undefined variable: databases C:\UwAmp\www\frisk\application\views\home_view.php 36
ERROR - 2017-06-06 20:23:31 --> Severity: Notice --> Undefined variable: databases C:\UwAmp\www\frisk\application\views\home_view.php 60
ERROR - 2017-06-06 20:23:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\home_view.php 60
ERROR - 2017-06-06 20:23:31 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\UwAmp\www\frisk\application\views\includes\footer.php 79
ERROR - 2017-06-06 20:24:10 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\UwAmp\www\frisk\application\views\includes\footer.php 79
ERROR - 2017-06-06 20:24:28 --> Severity: Notice --> Undefined variable: databases C:\UwAmp\www\frisk\application\views\home_view.php 36
ERROR - 2017-06-06 20:24:28 --> Severity: Notice --> Undefined variable: databases C:\UwAmp\www\frisk\application\views\home_view.php 60
ERROR - 2017-06-06 20:24:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\home_view.php 60
ERROR - 2017-06-06 20:24:28 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\UwAmp\www\frisk\application\views\includes\footer.php 79
ERROR - 2017-06-06 20:25:28 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\home_view.php 62
ERROR - 2017-06-06 20:25:28 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\home_view.php 68
ERROR - 2017-06-06 20:25:28 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\home_view.php 71
ERROR - 2017-06-06 20:25:28 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\home_view.php 62
ERROR - 2017-06-06 20:25:28 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\home_view.php 68
ERROR - 2017-06-06 20:25:28 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\home_view.php 71
ERROR - 2017-06-06 20:25:28 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\home_view.php 62
ERROR - 2017-06-06 20:25:28 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\home_view.php 68
ERROR - 2017-06-06 20:25:28 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\home_view.php 71
ERROR - 2017-06-06 20:25:28 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\home_view.php 62
ERROR - 2017-06-06 20:25:28 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\home_view.php 68
ERROR - 2017-06-06 20:25:28 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\home_view.php 71
ERROR - 2017-06-06 20:25:28 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\UwAmp\www\frisk\application\views\includes\footer.php 79
ERROR - 2017-06-06 20:27:20 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\UwAmp\www\frisk\application\views\includes\footer.php 79
ERROR - 2017-06-06 20:30:44 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\UwAmp\www\frisk\application\views\includes\footer.php 114
ERROR - 2017-06-06 20:31:20 --> Severity: Notice --> Undefined variable: data C:\UwAmp\www\frisk\application\views\includes\footer.php 9
ERROR - 2017-06-06 20:31:20 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\includes\footer.php 9
ERROR - 2017-06-06 20:31:20 --> Severity: Notice --> Undefined variable: data C:\UwAmp\www\frisk\application\views\includes\footer.php 10
ERROR - 2017-06-06 20:31:20 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\includes\footer.php 10
ERROR - 2017-06-06 20:31:20 --> Severity: Notice --> Undefined variable: data C:\UwAmp\www\frisk\application\views\includes\footer.php 11
ERROR - 2017-06-06 20:31:20 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\includes\footer.php 11
ERROR - 2017-06-06 20:31:20 --> Severity: Notice --> Undefined variable: database C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-06 20:31:20 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-06 20:31:20 --> Severity: Notice --> Undefined variable: database C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-06 20:31:55 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\includes\footer.php 9
ERROR - 2017-06-06 20:31:55 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\includes\footer.php 10
ERROR - 2017-06-06 20:31:55 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\includes\footer.php 11
ERROR - 2017-06-06 20:31:55 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-06 20:31:55 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-06 20:31:55 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-06 20:47:26 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\includes\footer.php 9
ERROR - 2017-06-06 20:47:26 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\includes\footer.php 10
ERROR - 2017-06-06 20:47:26 --> Severity: Notice --> Trying to get property of non-object C:\UwAmp\www\frisk\application\views\includes\footer.php 11
ERROR - 2017-06-06 20:47:26 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-06 20:47:26 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-06 20:47:26 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-06 20:48:31 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-06 20:48:31 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-06 20:48:31 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-06 20:49:54 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-06 20:49:54 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-06 20:49:54 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-06 20:50:32 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-06 20:50:32 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-06 20:50:32 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-06 20:51:42 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-06 20:51:42 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-06 20:51:42 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-06 20:53:22 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-06 20:53:22 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-06 20:53:22 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-06 20:54:21 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-06 20:54:21 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-06 20:54:21 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-06 20:54:54 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-06 20:54:54 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-06 20:54:54 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-06 20:55:08 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-06 20:55:08 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-06 20:55:08 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-06 20:55:34 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-06 20:55:34 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-06 20:55:34 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
