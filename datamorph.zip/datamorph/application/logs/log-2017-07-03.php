<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-03 10:37:22 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-07-03 10:37:43 --> 404 Page Not Found: Database/view
ERROR - 2017-07-03 10:37:47 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\create\database_form.php 1
