<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-05 17:51:34 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-07-05 18:10:22 --> Severity: Notice --> Undefined property: CI_Loader::$store C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 24
ERROR - 2017-07-05 18:10:22 --> Severity: Error --> Call to a member function menu() on null C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 24
ERROR - 2017-07-05 18:10:45 --> Severity: Notice --> Undefined property: CI_Loader::$store C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 43
ERROR - 2017-07-05 18:10:45 --> Severity: Error --> Call to a member function pages() on null C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 43
ERROR - 2017-07-05 18:10:56 --> Severity: Notice --> Undefined property: CI_Loader::$store C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 31
ERROR - 2017-07-05 18:10:56 --> Severity: Error --> Call to a member function pages() on null C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 31
ERROR - 2017-07-05 18:10:57 --> Severity: Notice --> Undefined property: CI_Loader::$store C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 31
ERROR - 2017-07-05 18:10:57 --> Severity: Error --> Call to a member function pages() on null C:\UwAmp\www\frisk\application\views\create\create_tables_view.php 31
ERROR - 2017-07-05 20:13:24 --> Severity: Notice --> Undefined property: Website::$database_model C:\UwAmp\www\frisk\application\controllers\Website.php 184
ERROR - 2017-07-05 20:13:24 --> Severity: Error --> Call to a member function create_session_table() on null C:\UwAmp\www\frisk\application\controllers\Website.php 184
ERROR - 2017-07-05 20:14:24 --> Severity: Error --> Call to undefined method Datamorph_model::is_session_table() C:\UwAmp\www\frisk\application\models\Datamorph_model.php 374
ERROR - 2017-07-05 20:32:49 --> 404 Page Not Found: Create/cancel
ERROR - 2017-07-05 20:36:44 --> 404 Page Not Found: Website/cancel
