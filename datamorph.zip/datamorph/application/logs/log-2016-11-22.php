<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-22 19:01:48 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:01:48 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 19:01:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 19:01:48 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 19:01:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 19:02:00 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting '(' C:\UwAmp\www\frisk\application\controllers\Action.php 131
ERROR - 2016-11-22 19:02:27 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:02:27 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:02:28 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 19:02:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 19:02:28 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 19:02:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 19:02:37 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:02:38 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:02:38 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 19:02:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 19:02:38 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 19:02:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 19:05:18 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:05:18 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 19:05:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 19:05:18 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 19:05:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 19:05:30 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:05:31 --> Severity: Warning --> Illegal string offset 'url' C:\UwAmp\www\frisk\application\controllers\Action.php 66
ERROR - 2016-11-22 19:05:34 --> Severity: Notice --> Undefined variable: image C:\UwAmp\www\frisk\application\controllers\Action.php 71
ERROR - 2016-11-22 19:30:59 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:30:59 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 19:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 19:30:59 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 19:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 19:31:10 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:36:08 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:36:09 --> Severity: Error --> Call to undefined function curren_url() C:\UwAmp\www\frisk\application\views\segments\images.php 13
ERROR - 2016-11-22 19:36:45 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:36:49 --> 404 Page Not Found: http://ignatiuswebsite/img/dveePNG/Download/file
ERROR - 2016-11-22 19:37:33 --> 404 Page Not Found: http://ignatiuswebsite/img/dveePNG/Download/file
ERROR - 2016-11-22 19:39:13 --> 404 Page Not Found: http://ignatiuswebsite/img/dveePNG/Download/file
ERROR - 2016-11-22 19:41:09 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:41:13 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:41:17 --> 404 Page Not Found: Download/images
ERROR - 2016-11-22 19:42:26 --> 404 Page Not Found: Download/images
ERROR - 2016-11-22 19:42:30 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:46:30 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:46:34 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:51:58 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:52:24 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:56:03 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:56:03 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 19:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 19:56:03 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 19:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 19:56:29 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 19:56:35 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 20:02:01 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 20:02:19 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 20:02:19 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:02:19 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:02:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\UwAmp\www\frisk\application\controllers\Browse.php:50) C:\UwAmp\www\frisk\system\core\Common.php 573
ERROR - 2016-11-22 20:02:20 --> Severity: Error --> Call to undefined method Crawler::setCrawlingDepthLimit() C:\UwAmp\www\frisk\application\models\Frisk.php 158
ERROR - 2016-11-22 20:03:20 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 20:03:20 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:03:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:03:20 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:03:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:03:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\UwAmp\www\frisk\application\controllers\Browse.php:50) C:\UwAmp\www\frisk\system\core\Common.php 573
ERROR - 2016-11-22 20:03:21 --> Severity: Error --> Call to undefined method Crawler::setCrawlingDepthLimit() C:\UwAmp\www\frisk\application\models\Frisk.php 158
ERROR - 2016-11-22 20:04:40 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 20:04:40 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:04:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:04:40 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:04:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:04:50 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 20:04:50 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:04:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:04:50 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:04:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:05:06 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 20:05:06 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:05:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:05:06 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:05:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:05:12 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 20:05:19 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 20:05:19 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:05:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:05:19 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:05:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:05:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\UwAmp\www\frisk\application\controllers\Browse.php:105) C:\UwAmp\www\frisk\system\core\Common.php 573
ERROR - 2016-11-22 20:05:26 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 20:05:26 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:05:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:05:26 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:05:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:05:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\UwAmp\www\frisk\application\controllers\Browse.php:105) C:\UwAmp\www\frisk\system\core\Common.php 573
ERROR - 2016-11-22 20:06:07 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 20:06:07 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:06:07 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:06:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\UwAmp\www\frisk\application\controllers\Browse.php:105) C:\UwAmp\www\frisk\system\core\Common.php 573
ERROR - 2016-11-22 20:09:19 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 20:09:19 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:09:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:09:19 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:09:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:09:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\UwAmp\www\frisk\application\controllers\Browse.php:105) C:\UwAmp\www\frisk\system\core\Common.php 573
ERROR - 2016-11-22 20:10:17 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2016-11-22 20:10:17 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 101
ERROR - 2016-11-22 20:10:17 --> Severity: Notice --> Undefined variable: items C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\UwAmp\www\frisk\application\views\includes\sub_header.php 107
ERROR - 2016-11-22 20:14:35 --> Cache: Failed to initialize APC; extension not loaded/enabled?
