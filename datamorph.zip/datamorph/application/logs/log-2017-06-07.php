<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-07 10:44:02 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-06-07 10:44:27 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:44:27 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:44:27 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:47:13 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:47:13 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:47:13 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:47:20 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:47:20 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:47:20 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:47:26 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:47:27 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:47:27 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:47:43 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:47:43 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:47:43 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:48:09 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:48:09 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:48:09 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:48:22 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:48:22 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:48:22 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:49:11 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:49:11 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:49:11 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:50:17 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:50:17 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:50:17 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:50:49 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:50:49 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:50:49 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:51:18 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:51:18 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:51:18 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:51:37 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:51:37 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:51:37 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:52:21 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:52:21 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:52:21 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:53:23 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:53:23 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:53:23 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:54:18 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:54:18 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:54:18 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:54:38 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:54:38 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:54:38 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:55:37 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:55:37 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:55:37 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:55:52 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:55:52 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:55:52 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:58:44 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:58:44 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:58:44 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:59:16 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:59:16 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:59:16 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 10:59:28 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 10:59:28 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 10:59:28 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 11:00:49 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 11:00:49 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 11:00:49 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 11:00:53 --> 404 Page Not Found: Database/view
ERROR - 2017-06-07 11:00:56 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 11:00:56 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 11:00:56 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 11:01:36 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 11:01:36 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 11:01:36 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 11:02:02 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 11:02:02 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 11:02:02 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 11:02:24 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 11:02:24 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 11:02:24 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 11:14:32 --> 404 Page Not Found: Database/view
ERROR - 2017-06-07 11:14:39 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 11:14:39 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 11:14:39 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 11:17:10 --> 404 Page Not Found: Database/view
ERROR - 2017-06-07 11:18:29 --> 404 Page Not Found: Database/index
ERROR - 2017-06-07 11:21:13 --> 404 Page Not Found: Website/database
ERROR - 2017-06-07 14:32:56 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-06-07 14:32:58 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-06-07 14:33:12 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 14:33:12 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 14:33:12 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 14:33:16 --> 404 Page Not Found: Create/index
ERROR - 2017-06-07 14:33:50 --> 404 Page Not Found: Create/index
ERROR - 2017-06-07 14:39:19 --> Severity: Notice --> Undefined property: Website::$database_model C:\UwAmp\www\frisk\application\controllers\Website.php 137
ERROR - 2017-06-07 14:39:19 --> Severity: Error --> Call to a member function get_session_database() on null C:\UwAmp\www\frisk\application\controllers\Website.php 137
ERROR - 2017-06-07 14:39:51 --> Severity: Notice --> Undefined property: Website::$datamorph_model C:\UwAmp\www\frisk\application\controllers\Website.php 137
ERROR - 2017-06-07 14:39:51 --> Severity: Error --> Call to a member function get_session_database() on null C:\UwAmp\www\frisk\application\controllers\Website.php 137
ERROR - 2017-06-07 14:40:48 --> Severity: Error --> Call to undefined method Datamorph_model::get_session_database() C:\UwAmp\www\frisk\application\controllers\Website.php 139
ERROR - 2017-06-07 14:44:30 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 14:44:31 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 14:44:31 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 14:46:13 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 14:46:13 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 14:46:13 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 14:46:46 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 14:46:46 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 14:46:46 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 14:47:08 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 14:47:08 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 14:47:08 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 14:47:13 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 14:47:13 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 14:47:13 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 14:47:53 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 14:47:53 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 14:47:53 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 14:48:29 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 14:48:29 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 14:48:29 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 14:48:52 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 23
ERROR - 2017-06-07 14:48:52 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\includes\footer.php 35
ERROR - 2017-06-07 14:48:52 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\includes\footer.php 45
ERROR - 2017-06-07 14:49:20 --> Severity: Error --> Call to undefined method Datamorph_model::create_session_database() C:\UwAmp\www\frisk\application\controllers\Website.php 148
ERROR - 2017-06-07 14:51:03 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting function (T_FUNCTION) C:\UwAmp\www\frisk\application\models\Datamorph_model.php 300
ERROR - 2017-06-07 14:54:02 --> Severity: Notice --> Undefined variable: fields C:\UwAmp\www\frisk\application\controllers\Website.php 155
ERROR - 2017-06-07 14:54:02 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\create\table_form.php 1
ERROR - 2017-06-07 14:54:02 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\create\table_form.php 3
