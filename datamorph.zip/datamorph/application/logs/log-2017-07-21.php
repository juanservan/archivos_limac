<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-21 18:02:56 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
