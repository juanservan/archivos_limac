<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-25 19:58:43 --> Severity: Notice --> Undefined variable: title C:\UwAmp\www\frisk\application\views\login_view.php 4
ERROR - 2017-06-25 20:00:16 --> 404 Page Not Found: Create/tables
ERROR - 2017-06-25 20:12:07 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\create\table_view.php 52
ERROR - 2017-06-25 20:12:07 --> Severity: Notice --> Undefined variable: validate C:\UwAmp\www\frisk\application\views\create\table_view.php 64
ERROR - 2017-06-25 20:12:07 --> Severity: Notice --> Undefined variable: infobase C:\UwAmp\www\frisk\application\views\create\table_view.php 74
ERROR - 2017-06-25 20:56:08 --> Severity: Notice --> Undefined variable: num C:\UwAmp\www\frisk\application\views\create\table_fields.php 4
